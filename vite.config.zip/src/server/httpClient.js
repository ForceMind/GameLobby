/**
 * HTTP API Client
 * 处理与后端服务器的所有 HTTP 通信
 */

import { socketClient } from ".";

// API 基础配置
export const API_BASE_URL = 'https://games-api.coconut.tv';
export const API_TIMEOUT = 10000; // 10秒超时
export const TEST_UID = "s7d8mynl-olnp-gv42-s71v-ada1d0kkwy68";
export const ROOM = "";
export const roomType = null;
export const ig = "22222222";
// API 端点定义
export const API_ENDPOINTS = {
    // 大厅相关
    lobby: '/game/lobby/login',
    init: '/game/lobby/InitReq',
    games: '/game/list',
    gameDetail: (id) => `/game/${id}`,

    // 用户相关
    user: '/user/profile',
    userBalance: '/user/balance',

    // 赛事相关
    arena: '/arena/list',
    arenaJoin: (id) => `/arena/${id}/join`,
    arenaLeaderboard: (id) => `/arena/${id}/leaderboard`,

    // 活动相关
    activities: '/activity/list',
    checkin: '/activity/checkin',
    tasks: '/activity/tasks',
    claimTask: '/activity/task/claim',
    wheelSpin: '/activity/wheel/spin',

    // 商城相关
    products: '/store/products',
    purchase: '/store/purchase',
    redeem: '/store/redeem',

    // 排行榜
    leaderboard: '/leaderboard/winners',

    // WebSocket 认证
    wsToken: '/ws/token',
};

/**
 * 自定义错误类
 */
export class ApiError extends Error {
    constructor(message, status, code) {
        super(message);
        this.name = 'ApiError';
        this.status = status;
        this.code = code;
    }
}

/**
 * 处理 API 响应
 */
function handleResponse(xhr, name) {
    return new Promise((resolve, reject) => {
        if (xhr.responseText.substring(0, 2) == "ws") {
            socketClient.connect(xhr.responseText);
        }
        else {
            const data = JSON.parse(xhr.responseText);
            console.log(`[API] ${name} ->`, data);
        }

        if (xhr.status >= 200 && xhr.status < 300) {
            if (name === API_ENDPOINTS.lobby) {

            }
            try {
                resolve(data);
            } catch (e) {
                resolve(xhr.responseText);
            }
        } else {
            try {
                const error = JSON.parse(xhr.responseText);
                console.log(`[API] ${name} <- Error:`, error);
                reject(new ApiError(error.message || `HTTP error ${xhr.status}`, xhr.status, error.code));
            } catch (e) {
                reject(new ApiError(`HTTP error ${xhr.status}`, xhr.status, 'UNKNOWN'));
            }
        }
    });
}

/**
 * 通用请求封装
 */
function request(method, endpoint, data = null, options = {}) {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        const url = `${API_BASE_URL}${endpoint}`;

        // 超时处理
        xhr.timeout = API_TIMEOUT;
        xhr.ontimeout = () => {
            reject(new ApiError('Request timeout', 408, 'TIMEOUT'));
        };

        // 请求完成
        xhr.onload = () => {
            resolve(handleResponse(xhr, endpoint));
        };

        // 错误处理
        xhr.onerror = () => {
            reject(new ApiError('Network error', 0, 'NETWORK_ERROR'));
        };

        // 构建查询参数
        const params = new URLSearchParams();
        params.append('uid', TEST_UID);
        params.append('room', ROOM);
        params.append('type', roomType);
        params.append('ig', ig);

        if (method === 'GET' && data) {
            Object.keys(data).forEach(key => {
                params.append(key, data[key]);
            });
        }

        // 配置请求
        if (method === 'GET') {
            const queryString = params.toString();
            xhr.open(method, queryString ? `${url}?${queryString}` : url, true);
        } else {
            xhr.open(method, url, true);
        }

        // 设置请求头
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('Accept', 'application/json');

        // 发送请求
        if (method === 'GET') {
            xhr.send();
        } else {
            const body = data ? JSON.stringify(data) : null;
            if (body) {
                // 添加额外参数到请求体
                const bodyObj = { ...data, uid: TEST_UID, roomId: ROOM, roomType: roomType, ig: ig };
                xhr.send(JSON.stringify(bodyObj));
            } else {
                xhr.send();
            }
        }
    });
}

/**
 * 通用 GET 请求
 */
export async function get(endpoint, options = {}) {
    return request('GET', endpoint, options);
}

/**
 * 通用 POST 请求
 */
export async function post(endpoint, data, options = {}) {
    return request('POST', endpoint, data);
}

// ==================== 业务 API 函数 ====================

/**
 * 获取大厅数据
 */
export async function fetchLobbyData() {
    return get(API_ENDPOINTS.lobby);
}
/**
 * 初始化
 * @returns 
 */
export async function initReq() {
    return get(API_ENDPOINTS.init);
}


/**
 * 获取游戏列表
 */
export async function fetchGames() {
    return get(API_ENDPOINTS.games);
}

/**
 * 获取游戏详情
 */
export async function fetchGameDetail(gameId) {
    return get(API_ENDPOINTS.gameDetail(gameId));
}

/**
 * 获取用户信息
 */
export async function fetchUserProfile() {
    return get(API_ENDPOINTS.user);
}

/**
 * 获取用户余额
 */
export async function fetchUserBalance() {
    return get(API_ENDPOINTS.userBalance);
}

/**
 * 获取赛事列表
 */
export async function fetchArenaList() {
    return get(API_ENDPOINTS.arena);
}

/**
 * 报名赛事
 */
export async function joinArena(arenaId) {
    return post(API_ENDPOINTS.arenaJoin(arenaId), {});
}

/**
 * 获取赛事排行榜
 */
export async function fetchArenaLeaderboard(arenaId) {
    return get(API_ENDPOINTS.arenaLeaderboard(arenaId));
}

/**
 * 获取活动列表
 */
export async function fetchActivities() {
    return get(API_ENDPOINTS.activities);
}

/**
 * 签到
 */
export async function doCheckin(day) {
    return post(API_ENDPOINTS.checkin, { day });
}

/**
 * 获取任务列表
 */
export async function fetchTasks() {
    return get(API_ENDPOINTS.tasks);
}

/**
 * 领取任务奖励
 */
export async function claimTaskReward(taskId) {
    return post(API_ENDPOINTS.claimTask, { taskId });
}

/**
 * 转盘抽奖
 */
export async function spinWheel() {
    return post(API_ENDPOINTS.wheelSpin, {});
}

/**
 * 获取商品列表
 */
export async function fetchProducts() {
    return get(API_ENDPOINTS.products);
}

/**
 * 购买商品
 */
export async function purchaseProduct(productId) {
    return post(API_ENDPOINTS.purchase, { productId });
}

/**
 * 兑换码兑换
 */
export async function redeemCode(code) {
    return post(API_ENDPOINTS.redeem, { code });
}

/**
 * 获取赢家排行榜
 */
export async function fetchLeaderboard() {
    return get(API_ENDPOINTS.leaderboard);
}

export default {
    get,
    post,
    ApiError,
    API_ENDPOINTS,
    fetchLobbyData,
    initReq,
    fetchGames,
    fetchGameDetail,
    fetchUserProfile,
    fetchUserBalance,
    fetchArenaList,
    joinArena,
    fetchArenaLeaderboard,
    fetchActivities,
    doCheckin,
    fetchTasks,
    claimTaskReward,
    spinWheel,
    fetchProducts,
    purchaseProduct,
    redeemCode,
    fetchLeaderboard,
};
