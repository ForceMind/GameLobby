/**
 * Server Module
 * 统一导出 HTTP 和 WebSocket 客户端
 */

export { default as httpClient } from './httpClient';
export { default as socketClient, wsClient, WS_EVENTS, useWebSocket } from './socketClient';
export { playerStore } from './player.js';

// HTTP API 方法
export {
    get,
    post,
    ApiError,
    API_BASE_URL,
    API_ENDPOINTS,
    fetchLobbyData,
    initReq,
    fetchGames,
    fetchGameDetail,
    fetchUserProfile,
    fetchUserBalance,
    fetchArenaList,
    joinArena,
    fetchArenaLeaderboard,
    fetchActivities,
    doCheckin,
    fetchTasks,
    claimTaskReward,
    spinWheel,
    fetchProducts,
    purchaseProduct,
    redeemCode,
    fetchLeaderboard,
} from './httpClient';
