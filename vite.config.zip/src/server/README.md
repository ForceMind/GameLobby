# Server Module

服务器通信模块，提供 HTTP API 和 WebSocket 实时通信功能。

## 文件结构

```
server/
├── index.js        # 统一导出
├── httpClient.js   # HTTP API 客户端
├── socketClient.js # WebSocket 客户端
└── README.md       # 使用说明
```

## HTTP API 使用

```javascript
import { fetchLobbyData, fetchGames, joinArena } from './server';

// 获取大厅数据
const lobbyData = await fetchLobbyData();

// 获取游戏列表
const games = await fetchGames();

// 报名赛事
const result = await joinArena('arena-123');
```

### 可用 API 方法

| 方法 | 描述 |
|------|------|
| `fetchLobbyData()` | 获取大厅数据 |
| `fetchGames()` | 获取游戏列表 |
| `fetchGameDetail(gameId)` | 获取游戏详情 |
| `fetchUserProfile()` | 获取用户信息 |
| `fetchUserBalance()` | 获取用户余额 |
| `fetchArenaList()` | 获取赛事列表 |
| `joinArena(arenaId)` | 报名赛事 |
| `fetchArenaLeaderboard(arenaId)` | 获取赛事排行榜 |
| `fetchActivities()` | 获取活动列表 |
| `doCheckin(day)` | 签到 |
| `fetchTasks()` | 获取任务列表 |
| `claimTaskReward(taskId)` | 领取任务奖励 |
| `spinWheel()` | 转盘抽奖 |
| `fetchProducts()` | 获取商品列表 |
| `purchaseProduct(productId)` | 购买商品 |
| `redeemCode(code)` | 兑换码兑换 |
| `fetchLeaderboard()` | 获取赢家排行榜 |

### 错误处理

```javascript
import { fetchLobbyData, ApiError } from './server';

try {
    const data = await fetchLobbyData();
    // 处理数据
} catch (error) {
    if (error instanceof ApiError) {
        console.error(`API Error: ${error.message} (Status: ${error.status})`);
    }
}
```

## WebSocket 使用

### 基本连接

```javascript
import { wsClient, WS_EVENTS } from './server';

// 连接服务器
wsClient.connect();

// 监听连接成功
wsClient.on(WS_EVENTS.CONNECTED, () => {
    console.log('WebSocket connected');
    // 订阅感兴趣的内容
    wsClient.subscribeGame('golden-pharaoh');
});

// 监听断开连接
wsClient.on(WS_EVENTS.DISCONNECTED, (data) => {
    console.log('Disconnected:', data.reason);
});

// 监听重连
wsClient.on(WS_EVENTS.RECONNECTING, ({ attempt, delay }) => {
    console.log(`Reconnecting... Attempt ${attempt}`);
});

// 断开连接
wsClient.disconnect();
```

### 监听游戏事件

```javascript
import { wsClient, WS_EVENTS } from './server';

// 监听 Jackpot 中奖
wsClient.on(WS_EVENTS.JACKPOT_WIN, (data) => {
    showNotification(`恭喜 ${data.userName} 获得 Jackpot ${data.amount}!`);
});

// 监听大奖
wsClient.on(WS_EVENTS.BIG_WIN, (data) => {
    showBigWinAnimation(data);
});

// 监听余额更新
wsClient.on(WS_EVENTS.BALANCE_UPDATE, (data) => {
    updateUserBalance(data.coins, data.activityCoins);
});

// 监听赛事更新
wsClient.on(WS_EVENTS.ARENA_UPDATE, (data) => {
    updateArenaStatus(data);
});

// 监听排名变化
wsClient.on(WS_EVENTS.RANK_CHANGE, (data) => {
    showRankChange(data);
});
```

### 订阅/取消订阅

```javascript
// 订阅游戏
wsClient.subscribeGame('golden-pharaoh');

// 取消订阅
wsClient.unsubscribeGame('golden-pharaoh');

// 订阅赛事
wsClient.subscribeArena('arena-123');

// 订阅活动
wsClient.subscribeActivity('weekend-party');
```

### 发送自定义消息

```javascript
// 发送消息到服务器
wsClient.send('custom_event', { key: 'value' });
```

## WebSocket 事件类型

```javascript
// 连接状态
WS_EVENTS.CONNECTED      // 连接成功
WS_EVENTS.DISCONNECTED   // 连接断开
WS_EVENTS.ERROR          // 错误发生
WS_EVENTS.RECONNECTING   // 正在重连

// 游戏事件
WS_EVENTS.GAME_UPDATE    // 游戏状态更新
WS_EVENTS.GAME_START    // 游戏开始
WS_EVENTS.GAME_END      // 游戏结束
WS_EVENTS.JACKPOT_WIN   // Jackpot 中奖
WS_EVENTS.BIG_WIN       // 大奖

// 赛事事件
WS_EVENTS.ARENA_UPDATE  // 赛事状态更新
WS_EVENTS.ARENA_START   // 赛事开始
WS_EVENTS.ARENA_END     // 赛事结束
WS_EVENTS.RANK_CHANGE   // 排名变化

// 活动事件
WS_EVENTS.ACTIVITY_START // 活动开始
WS_EVENTS.ACTIVITY_END   // 活动结束

// 其他
WS_EVENTS.BALANCE_UPDATE // 余额更新
WS_EVENTS.MESSAGE       // 通用消息
```

## 配置

### 修改 API 基础 URL

在 `httpClient.js` 中修改：

```javascript
const API_BASE_URL = 'https://your-api-server.com';
```

### 修改 WebSocket 重连策略

在 `socketClient.js` 中修改：

```javascript
this.maxReconnectAttempts = 5;  // 最大重连次数
this.reconnectDelay = 1000;     // 初始重连延迟(ms)
this.pingIntervalTime = 30000;   // 心跳间隔(ms)
```
