﻿import { useEffect, useMemo, useRef, useState } from 'react';
import {
    FaBell,
    FaBolt,
    FaCalendarCheck,
    FaChevronRight,
    FaCrown,
    FaFire,
    FaFlag,
    FaGamepad,
    FaGift,
    FaHistory,
    FaHome,
    FaMedal,
    FaPlayCircle,
    FaRocket,
    FaShoppingBag,
    FaStar,
    FaTrophy,
    FaUser,
    FaUsers,
    FaWallet,
} from 'react-icons/fa';
import './App.css';
import { httpClient, socketClient, playerStore, WS_EVENTS } from './server';

const tabs = [
    { id: 'lobby', label: '大厅', icon: FaHome },
    //{ id: 'arena', label: '赛事', icon: FaTrophy },
    //{ id: 'events', label: '活动', icon: FaCalendarCheck },
    //{ id: 'store', label: '商城', icon: FaShoppingBag },
    { id: 'profile', label: '我的', icon: FaUser },
];

const heroBanners = [
    {
        title: 'Lucky Spin 狂欢季',
        subtitle: '主奖池 8,880,000 金币',
        badge: '限时 Free Spin x20',
        cta: '立即开转',
        accent: 'var(--accent-orange)',
    },
    {
        title: 'Classic Slot 周挑战',
        subtitle: '经典三轴和五轴 Slot 同台冲榜',
        badge: 'Jackpot 双倍时段',
        cta: '去玩 Slot',
        accent: 'var(--accent-cyan)',
    },
    {
        title: '休闲轻松局',
        subtitle: '捕鱼、消除、跑酷，轻松拿奖励',
        badge: '放松专区上线',
        cta: '马上体验',
        accent: 'var(--accent-green)',
    },
];

// 备用静态游戏列表（服务器不可用时使用）
const defaultGames = [
    { id: 'golden-pharaoh', name: 'Golden Pharaoh', category: 'Slots', players: '4.8k', heat: 99, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'JACKPOT' },
    { id: 'ocean-777', name: 'Ocean 777', category: 'Slots', players: '3.9k', heat: 96, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'HOT' },
    { id: 'fruit-party', name: 'Fruit Party', category: 'Slots', players: '3.2k', heat: 93, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'TREND' },
    { id: 'wild-west', name: 'Wild West Deluxe', category: 'Slots', players: '2.6k', heat: 90, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'NEW' },
    { id: 'fish-hunter', name: 'Fish Hunter', category: '休闲', players: '2.1k', heat: 88, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'FUN' },
    { id: 'bubble-pop', name: 'Bubble Pop', category: '休闲', players: '1.7k', heat: 84, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'EASY' },
    { id: 'dice-merge', name: 'Dice Merge', category: '休闲', players: '1.4k', heat: 82, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'RELAX' },
    { id: 'mini-golf', name: 'Mini Golf Rush', category: '休闲', players: '1.1k', heat: 80, backgroundUrl: 'https://cdn.example.com/games/pharaoh-bg.jpg', label: 'COZY' },
];

const testGames = [{ "id": 3033, "name": "Cyberpunk -Test", "icon": "https://games-web.coconut.tv/icon/cyberpunk.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=3033&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=oA&v=57321&ig=WC2sfFYf", "type": 4 }, { "id": 1026, "name": "fish", "icon": "https://games-web.coconut.tv/icon/fish.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1026&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lD&v=49184&ig=WC2sfFYf", "type": 1 }, { "id": 1024, "name": "777", "icon": "https://games-web.coconut.tv/icon/777.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1024&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lB&v=7863&ig=WC2sfFYf", "type": 0 }, { "id": 1027, "name": "Dragon", "icon": "https://games-web.coconut.tv/icon/dragon.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1027&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lE&v=45443&ig=WC2sfFYf", "type": 0 }, { "id": 1031, "name": "space", "icon": "https://games-web.coconut.tv/icon/space.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1031&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=my&v=40766&ig=WC2sfFYf", "type": 0 }, { "id": 1010, "name": "Pharaoh", "icon": "https://games-web.coconut.tv/icon/pharaoh.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1010&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=kx&v=2061&ig=WC2sfFYf", "type": 0 }, { "id": 1013, "name": "Pirates", "icon": "https://games-web.coconut.tv/icon/pirate.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1013&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=kA&v=61991&ig=WC2sfFYf", "type": 0 }, { "id": 1011, "name": "Buffalo", "icon": "https://games-web.coconut.tv/icon/buffalo.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1011&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=ky&v=88492&ig=WC2sfFYf", "type": 0 }, { "id": 1017, "name": "Zeus", "icon": "https://games-web.coconut.tv/icon/zeus.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1017&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=kE&v=89308&ig=WC2sfFYf", "type": 0 }, { "id": 1019, "name": "Vegas", "icon": "https://games-web.coconut.tv/icon/vegas.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1019&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=kG&v=15103&ig=WC2sfFYf", "type": 0 }, { "id": 1020, "name": "Tiger", "icon": "https://games-web.coconut.tv/icon/tiger.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1020&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lx&v=91489&ig=WC2sfFYf", "type": 0 }, { "id": 1007, "name": "FruitSpin", "icon": "https://games-web.coconut.tv/icon/fruit.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1007&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=jE&v=92562&ig=WC2sfFYf", "type": 0 }, { "id": 1022, "name": "R&W", "icon": "https://games-web.coconut.tv/icon/rw.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1022&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lz&v=56282&ig=WC2sfFYf", "type": 0 }, { "id": 1025, "name": "Pearl", "icon": "https://games-web.coconut.tv/icon/pearl.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1025&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lC&v=20023&ig=WC2sfFYf", "type": 0 }, { "id": 1023, "name": "Bells", "icon": "https://games-web.coconut.tv/icon/bells.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1023&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lA&v=40835&ig=WC2sfFYf", "type": 0 }, { "id": 1001, "name": "GameSlots", "icon": "https://games-web.coconut.tv/icon/slots.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1001&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=jy&v=27718&ig=WC2sfFYf", "type": 0 }, { "id": 5108, "name": "PirateKing", "icon": "https://games-web.coconut.tv/icon/PirateKing_icon_240.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=5108&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=nG&v=0&ig=WC2sfFYf", "type": 0 }, { "id": 5119, "name": "YummySlot", "icon": "https://games-web.coconut.tv/icon/YummySlot_icon_240.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=5119&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=oH&v=0&ig=WC2sfFYf", "type": 0 }, { "id": 5145, "name": "OlympusSlot", "icon": "https://games-web.coconut.tv/icon/OlympusSlot_Icon_240.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=5145&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=rD&v=0&ig=WC2sfFYf", "type": 0 }, { "id": 5152, "name": "LavaSlot", "icon": "https://games-web.coconut.tv/icon/lavaslot_icon_240.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=5152&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=sA&v=0&ig=WC2sfFYf", "type": 0 }, { "id": 5153, "name": "FortuneSlot", "icon": "https://games-web.coconut.tv/icon/FortuneSlot_icon_240.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=5153&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=sB&v=0&ig=WC2sfFYf", "type": 0 }, { "id": 6036, "name": "Bingo", "icon": "https://games-web.coconut.tv/icon/bingo.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6036&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=rD&v=79954&ig=WC2sfFYf", "type": 2 }, { "id": 6037, "name": "Charmed", "icon": "https://games-web.coconut.tv/icon/charmed.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6037&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=rE&v=51656&ig=WC2sfFYf", "type": 2 }, { "id": 6035, "name": "Billionaire", "icon": "https://games-web.coconut.tv/icon/billionaire.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6035&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=rC&v=89946&ig=WC2sfFYf", "type": 1 }, { "id": 6007, "name": "FruitSpin 3", "icon": "https://games-web.coconut.tv/icon/fruit.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6007&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=oE&v=17045&ig=WC2sfFYf", "type": 0 }, { "id": 6014, "name": "JetSet 3", "icon": "https://games-web.coconut.tv/icon/jetset.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6014&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=pB&v=75509&ig=WC2sfFYf", "type": 0 }, { "id": 6019, "name": "Vegas 3", "icon": "https://games-web.coconut.tv/icon/vegas.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6019&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=pG&v=45375&ig=WC2sfFYf", "type": 0 }, { "id": 6020, "name": "Tiger 3", "icon": "https://games-web.coconut.tv/icon/tiger.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6020&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=qx&v=83611&ig=WC2sfFYf", "type": 0 }, { "id": 6022, "name": "R&W 3", "icon": "https://games-web.coconut.tv/icon/rw.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6022&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=qz&v=43820&ig=WC2sfFYf", "type": 0 }, { "id": 6023, "name": "Bells 3", "icon": "https://games-web.coconut.tv/icon/bells.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6023&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=qA&v=55570&ig=WC2sfFYf", "type": 0 }, { "id": 6025, "name": "Pearl 3", "icon": "https://games-web.coconut.tv/icon/pearl.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6025&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=qC&v=46135&ig=WC2sfFYf", "type": 0 }, { "id": 6031, "name": "space 3", "icon": "https://games-web.coconut.tv/icon/space.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6031&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=ry&v=17570&ig=WC2sfFYf", "type": 0 }, { "id": 6017, "name": "Zeus 3", "icon": "https://games-web.coconut.tv/icon/zeus.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6017&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=pE&v=46579&ig=WC2sfFYf", "type": 0 }, { "id": 6013, "name": "Pirates 3", "icon": "https://games-web.coconut.tv/icon/pirate.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6013&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=pA&v=6355&ig=WC2sfFYf", "type": 0 }, { "id": 6024, "name": "777 3", "icon": "https://games-web.coconut.tv/icon/777.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6024&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=qB&v=93193&ig=WC2sfFYf", "type": 0 }, { "id": 6010, "name": "Pharaoh 3", "icon": "https://games-web.coconut.tv/icon/pharaoh.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6010&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=px&v=40566&ig=WC2sfFYf", "type": 0 }, { "id": 6027, "name": "Dragon 3", "icon": "https://games-web.coconut.tv/icon/dragon.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6027&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=qE&v=95335&ig=WC2sfFYf", "type": 0 }, { "id": 6011, "name": "Buffalo 3", "icon": "https://games-web.coconut.tv/icon/buffalo.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6011&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=py&v=72017&ig=WC2sfFYf", "type": 0 }, { "id": 6016, "name": "Cleo 3", "icon": "https://games-web.coconut.tv/icon/cleo.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6016&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=pD&v=17587&ig=WC2sfFYf", "type": 0 }, { "id": 6001, "name": "GameSlots 3", "icon": "https://games-web.coconut.tv/icon/slots.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=6001&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=oy&v=46223&ig=WC2sfFYf", "type": 0 }, { "id": 1005, "name": "Flutter Fly", "icon": "https://games-web.coconut.tv/icon/flappybird.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1005&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=jC&v=71331&ig=WC2sfFYf", "type": 0 }, { "id": 1006, "name": "Mines", "icon": "https://games-web.coconut.tv/icon/mines.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1006&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=jD&v=78315&ig=WC2sfFYf", "type": 0 }, { "id": 1009, "name": "FreeSlot", "icon": "https://games-web.coconut.tv/icon/free.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1009&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=jG&v=84550&ig=WC2sfFYf", "type": 0 }, { "id": 1028, "name": "Dice", "icon": "https://games-web.coconut.tv/icon/dice.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1028&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lF&v=83428&ig=WC2sfFYf", "type": 0 }, { "id": 1029, "name": "MahJong", "icon": "https://games-web.coconut.tv/icon/MayicMahJong.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1029&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=lG&v=60505&ig=WC2sfFYf", "type": 0 }, { "id": 1030, "name": "block", "icon": "https://games-web.coconut.tv/icon/block.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=1030&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=mx&v=21360&ig=WC2sfFYf", "type": 0 }, { "id": 2025, "name": "Joy Fish", "icon": "https://games-web.coconut.tv/icon/joyfishing.png", "url": "https://games-api.coconut.tv/game/lobby/gameUrl?gid=2025&uid=hqd2xof7-uakj-ffbo-k0rp-zdqriuk2s8nq&m=mC&v=0&ig=WC2sfFYf", "type": 0 }]
const quickActions = [
    { id: 'freespin', title: '免费旋转', sub: '领取今日 Free Spin', icon: FaGift },
    { id: 'jackpot', title: 'Jackpot 池', sub: '查看实时大奖金额', icon: FaBolt },
    { id: 'mission', title: '新手任务', sub: '完成任务加速成长', icon: FaFlag },
    { id: 'history', title: '最近中奖', sub: '查看最近 20 条记录', icon: FaHistory },
];

const arenaCards = [
    {
        id: 'slot-ladder',
        title: 'Slot 冲榜赛',
        mode: 'Mega Ways 模式',
        prize: '￥ 88,888',
        team: '1,122 / 2,000 名玩家',
        progress: 56,
        entryFee: '2,000 金币',
        requirement: '账号等级 >= 5',
        settlement: '每晚 22:10 统一结算',
        rules: [
            '每 50 次有效旋转记 1 局，单次旋转最低 20 金币。',
            '仅统计当日 00:00 - 22:00 的净收益作为赛事积分。',
            '中途退出保留已得积分，重新进入不重置。'
        ],
        personnel: [
            { label: '已报名', value: '1,122' },
            { label: '在线中', value: '846' },
            { label: '等待中', value: '138' },
            { label: '已淘汰', value: '92' }
        ],
        rewards: [
            '第 1 名：68,000 金币 + 180 活动币',
            '第 2-10 名：8,000 金币 + 60 活动币',
            '第 11-100 名：2,000 金币 + 20 活动币'
        ],
    },
    {
        id: 'jackpot-cup',
        title: 'Jackpot 争夺赛',
        mode: 'Progressive Slot',
        prize: '￥ 28,000',
        team: '932 / 1,500 名玩家',
        progress: 62,
        entryFee: '1,500 金币',
        requirement: '近 3 天内有 1 次 Slot 记录',
        settlement: '每晚 21:40 统一结算',
        rules: [
            '赛事期间触发 Jackpot 可获得额外积分加成。',
            '单局最高积分按净赢金币分段计算，上限 10,000 分。',
            '若积分相同，按完成局数较少者排名更高。'
        ],
        personnel: [
            { label: '已报名', value: '932' },
            { label: '在线中', value: '664' },
            { label: '等待中', value: '120' },
            { label: '已淘汰', value: '58' }
        ],
        rewards: [
            '第 1 名：28,000 金币 + 120 活动币',
            '第 2-20 名：3,000 金币 + 36 活动币',
            '参与奖：300 金币 + 6 活动币'
        ],
    },
    {
        id: 'casual-cup',
        title: '休闲积分挑战',
        mode: '捕鱼 + 消除',
        prize: '￥ 12,000',
        team: '488 / 800 名玩家',
        progress: 61,
        entryFee: '800 金币',
        requirement: '账号等级 >= 3',
        settlement: '每晚 20:30 统一结算',
        rules: [
            '仅统计休闲专区指定游戏，不计入 Slot 局数。',
            '每局胜利 +3 分，失败 +1 分，连胜有额外乘区。',
            '禁止代打与脚本操作，检测异常将取消资格。'
        ],
        personnel: [
            { label: '已报名', value: '488' },
            { label: '在线中', value: '352' },
            { label: '等待中', value: '84' },
            { label: '已淘汰', value: '26' }
        ],
        rewards: [
            '第 1 名：12,000 金币 + 80 活动币',
            '第 2-30 名：1,200 金币 + 18 活动币',
            '参与奖：150 金币 + 3 活动币'
        ],
    },
];

const arenaGlobalRules = [
    '所有赛事均使用金币报名，活动币仅用于活动商店兑换。',
    '每日同一账号最多报名 3 场赛事，重复报名将自动退回手续费后拒绝。',
    '若网络中断超过 3 分钟，系统将以中断前最后一局成绩结算。',
    '赛果以服务器记录为准，最终解释权归 cocogames 赛事中心。'
];

const arenaPopulation = [
    { label: '当前在线参赛', value: 1862, ratio: 93 },
    { label: '已报名待开赛', value: 342, ratio: 42 },
    { label: '候补队列', value: 118, ratio: 28 },
    { label: '裁判与风控席位', value: 24, ratio: 12 }
];

const missionSeed = [
    { id: 'm1', title: '累计旋转 100 次', progress: 68, total: 100, coinReward: 300, tokenReward: 4 },
    { id: 'm2', title: '完成 5 局休闲游戏', progress: 3, total: 5, coinReward: 200, tokenReward: 6 },
    { id: 'm3', title: '触发 1 次 Free Spin', progress: 1, total: 1, coinReward: 500, tokenReward: 8 },
    { id: 'm4', title: '分享一次中奖记录', progress: 0, total: 1, coinReward: 120, tokenReward: 3 },
];

const coinPacks = [
    { id: 'p1', coin: '6,000', bonus: '+8%', price: '￥6', tag: '首充', tokenBonus: 2 },
    { id: 'p2', coin: '30,000', bonus: '+18%', price: '￥30', tag: '热门', tokenBonus: 10 },
    { id: 'p3', coin: '68,000', bonus: '+28%', price: '￥68', tag: '超值', tokenBonus: 25 },
    { id: 'p4', coin: '128,000', bonus: '+40%', price: '￥128', tag: '推荐', tokenBonus: 50 },
];

const leaderboard = [
    { name: 'ReelMaster', score: 128800, streak: '最高连中 6 次' },
    { name: 'LuckyBean', score: 106420, streak: '最高连中 5 次' },
    { name: 'SpinKing', score: 98880, streak: '触发 3 次 Jackpot' },
    { name: 'FishHero', score: 87500, streak: '休闲连胜 9 局' },
];

const profileRecords = [
    { id: 'r1', game: 'Golden Pharaoh', type: 'Slots', coin: 12600, token: 6, time: '今天 20:18' },
    { id: 'r2', game: 'Fish Hunter', type: '休闲', coin: -1200, token: 1, time: '今天 18:52' },
    { id: 'r3', game: 'Ocean 777', type: 'Slots', coin: 8800, token: 4, time: '今天 16:10' },
    { id: 'r4', game: 'Bubble Pop', type: '休闲', coin: 900, token: 2, time: '今天 14:36' },
    { id: 'r5', game: 'Wild West Deluxe', type: 'Slots', coin: -3600, token: 0, time: '今天 12:28' },
];

const profileSecurity = [
    { label: '手机号绑定', value: '138****6651', status: '已完成' },
    { label: '登录保护', value: '设备验证已开启', status: '已开启' },
    { label: '支付密码', value: '已设置，7 天前更新', status: '正常' },
    { label: '异常登录检测', value: '近 30 天无风险', status: '安全' },
];

function App() {
    const initRef = useRef(false);
    const [activeTab, setActiveTab] = useState('lobby');
    const [activeCategory, setActiveCategory] = useState('全部');
    const [bannerIndex, setBannerIndex] = useState(0);
    const [coins, setCoins] = useState(0);
    const [activityCoins, setActivityCoins] = useState(0);
    const [nickname, setNickname] = useState('cocogames');
    const [avatar, setAvatar] = useState('');
    const [toast, setToast] = useState('');
    const [pickedDays, setPickedDays] = useState([true, true, false, false, false, false, false]);
    const [missions, setMissions] = useState(missionSeed);
    const [spinAngle, setSpinAngle] = useState(0);
    const [isSpinning, setIsSpinning] = useState(false);
    const [selectedGame, setSelectedGame] = useState(null);
    // 从服务器动态获取游戏列表
    const [games, setGames] = useState([]);
    const [gamesLoading, setGamesLoading] = useState(true);
    // 游戏 iframe 窗口
    const [gameFrameUrl, setGameFrameUrl] = useState(null);
    // 连接状态管理
    const [connectionStatus, setConnectionStatus] = useState('connecting'); // 'connecting' | 'connected' | 'error'
    const [connectionError, setConnectionError] = useState(null);
    // 公告列表
    const [apnsList, setApnsList] = useState([]);
    // 初始化网络登录（仅调用一次）
    useEffect(() => {
        if (initRef.current) return;
        initRef.current = true;
        // 先连接 WebSocket，连接成功后再显示大厅
        initializeConnection();
    }, []);
    // 初始化连接：先连 WebSocket，再获取数据
    const initializeConnection = async () => {
        try {
            setConnectionStatus('connecting');
            setConnectionError(null);
            // 1. 先获取大厅登录数据（包含 WebSocket 地址）
            await httpClient.fetchLobbyData();
            // 2. 等待 WebSocket 连接成功
            socketClient.once(WS_EVENTS.InitReq, () => {
                console.log('[App] WebSocket connected, loading games...');
                setConnectionStatus('connected');
                // 3. 获取游戏列表
                fetchGames();
                // 4. 获取公告列表
                socketClient.GetApnsReq();
            });
            // 3. 监听连接错误
            socketClient.once(WS_EVENTS.ERROR, (error) => {
                console.error('[App] WebSocket connection failed:', error);
                setConnectionStatus('error');
                setConnectionError('连接服务器失败，请检查网络后重试');
            });
        } catch (error) {
            console.error('[App] Initialization failed:', error);
            setConnectionStatus('error');
            setConnectionError('初始化失败，请刷新页面重试');
        }
    };
    // 从服务器获取游戏列表，失败时使用默认列表
    const fetchGames = async () => {
        try {
            setGamesLoading(true);
            // const response = await httpClient.get('/games');
            // 使用服务器数据，如果没有则使用默认列表
            console.log("获取游戏列表", playerStore.gameList);
            setGames(playerStore.gameList);
        } catch (error) {
            console.error('获取游戏列表失败，使用默认列表:', error);
            setGames(testGames);  // 失败时使用默认列表
            setToast('使用离线游戏列表');
        } finally {
            setGamesLoading(false);
        }
    };

    // 监听玩家数据更新，同步金币和昵称
    useEffect(() => {
        const unsubscribe = playerStore.on('userUpdate', (user) => {
            setCoins(user.token || 0);
            setNickname(user.nickname || 'cocogames');
            setAvatar(user.avatar || '');
        });
        return unsubscribe;
    }, []);

    // 监听公告更新
    useEffect(() => {
        const unsubscribe = socketClient.on(WS_EVENTS.APNS_UPDATE, (apns) => {
            setApnsList(apns || []);
        });
        return unsubscribe;
    }, []);

    useEffect(() => {
        const timer = setInterval(() => {
            setBannerIndex((prev) => (prev + 1) % heroBanners.length);
        }, 4500);
        return () => clearInterval(timer);
    }, []);

    useEffect(() => {
        if (!toast) {
            return undefined;
        }
        const timer = setTimeout(() => setToast(''), 1800);
        return () => clearTimeout(timer);
    }, [toast]);

    // 接收 window.postMessage 消息
    useEffect(() => {
        const handleMessage = (event) => {
            console.log('[App] Received postMessage:', event.data);
            const { type, data } = event.data || {};

            // 根据消息类型处理
            switch (type) {
                case 'gameResult':
                    // 游戏结果，更新金币
                    if (data?.coins) {
                        setCoins((prev) => prev + data.coins);
                        setToast(`游戏赢得 ${data.coins} 金币`);
                    }
                    break;
                case 'gameExit':
                    // 游戏退出，关闭 iframe
                    setGameFrameUrl(null);
                    break;
                case 'balanceUpdate':
                    // 余额更新
                    if (data?.coins !== undefined) setCoins(data.coins);
                    if (data?.activityCoins !== undefined) setActivityCoins(data.activityCoins);
                    break;
                case 'achievement':
                    // 成就解锁
                    if (data?.title) {
                        setToast(`🏆 成就解锁: ${data.title}`);
                    }
                    break;
                default:
                    console.log('[App] Unknown message type:', type);
            }
        };

        window.addEventListener('message', handleMessage,false);
        // return () =>   window.removeEventListener('message', handleMessage);
    }, []);

    const categories = useMemo(() => ['全部', ...new Set(games.map((item) => item.category))], []);

    const displayGames = useMemo(() => {
        if (activeCategory === '全部') {
            return games;
        }
        return games.filter((item) => item.category === activeCategory);
    }, [activeCategory, games]);

    const currentBanner = heroBanners[bannerIndex];
    const renderRewardText = (coinReward, tokenReward) => `${coinReward} 金币 + ${tokenReward} 活动币`;

    const claimDay = (index) => {
        if (pickedDays[index]) {
            return;
        }
        const next = [...pickedDays];
        next[index] = true;
        setPickedDays(next);
        const coinGain = index === 6 ? 588 : 188;
        const tokenGain = index === 6 ? 6 : 1;
        setCoins((prev) => prev + coinGain);
        setActivityCoins((prev) => prev + tokenGain);
        setToast(`签到成功 +${coinGain} 金币 +${tokenGain} 活动币`);
    };

    const claimMission = (id) => {
        const mission = missions.find((item) => item.id === id);
        if (!mission || mission.progress < mission.total) {
            setToast('任务未完成');
            return;
        }
        const coinGain = mission.coinReward ?? 0;
        const tokenGain = mission.tokenReward ?? 0;
        setCoins((prev) => prev + coinGain);
        setActivityCoins((prev) => prev + tokenGain);
        setMissions((prev) => prev.filter((item) => item.id !== id));
        setToast(`任务奖励 +${coinGain} 金币 +${tokenGain} 活动币`);
    };

    const spinLuckyWheel = () => {
        if (isSpinning) {
            return;
        }
        setIsSpinning(true);
        const delta = 1800 + Math.floor(Math.random() * 360);
        setSpinAngle((prev) => prev + delta);
        window.setTimeout(() => {
            setIsSpinning(false);
            const reward = [
                { coin: 188, token: 0 },
                { coin: 388, token: 2 },
                { coin: 588, token: 4 },
                { coin: 888, token: 8 },
            ][Math.floor(Math.random() * 4)];
            setCoins((prev) => prev + reward.coin);
            setActivityCoins((prev) => prev + reward.token);
            setToast(`转盘奖励 +${reward.coin} 金币 +${reward.token} 活动币`);
        }, 3600);
    };

    const buyPack = (pack) => {
        const amount = Number(pack.coin.replaceAll(',', ''));
        const bonusRate = Number(pack.bonus.replace('+', '').replace('%', '')) / 100;
        const total = Math.round(amount * (1 + bonusRate));
        const tokenBonus = pack.tokenBonus ?? 0;
        setCoins((prev) => prev + total);
        setActivityCoins((prev) => prev + tokenBonus);
        setToast(`充值到账 ${total.toLocaleString()} 金币 +${tokenBonus} 活动币`);
    };

    const launchGame = (game) => {
        setSelectedGame(game);
    };

    const renderSectionHeader = (title, desc, action = '查看更多') => (
        <div className="section-header">
            <div>
                <h2>{title}</h2>
                <p>{desc}</p>
            </div>
            <button className="text-action" type="button">
                {action}
                <FaChevronRight />
            </button>
        </div>
    );

    const renderLobby = () => (
        <div className="page-stack">
            <section className="hero-card" style={{ '--hero-accent': currentBanner.accent }}>
                <span className="hero-badge">{currentBanner.badge}</span>
                <h1>{currentBanner.title}</h1>
                <p>{currentBanner.subtitle}</p>
                <div className="hero-actions">
                    <button type="button" className="btn-primary">
                        <FaPlayCircle />
                        {currentBanner.cta}
                    </button>
                    <button type="button" className="btn-glass">
                        <FaGift />
                        福利中心
                    </button>
                </div>
                <div className="hero-dots" aria-hidden="true">
                    {heroBanners.map((_, index) => (
                        <span key={index} className={index === bannerIndex ? 'dot active' : 'dot'} />
                    ))}
                </div>
            </section>

            <section className="card-shell quick-panel">
                {quickActions.map((action, index) => {
                    const Icon = action.icon;
                    return (
                        <button
                            type="button"
                            key={action.id}
                            className="quick-action"
                            style={{ animationDelay: `${index * 90}ms` }}
                            onClick={() => setToast(`${action.title} 已打开`)}
                        >
                            <div className="quick-icon">
                                <Icon />
                            </div>
                            <div>
                                <h3>{action.title}</h3>
                                <p>{action.sub}</p>
                            </div>
                        </button>
                    );
                })}
            </section>

            <section className="card-shell">
                {renderSectionHeader('热门 Slot 与休闲', '主打 Slot，补充轻量休闲游戏，支持即点即玩')}
                <div className="category-row">
                    {categories.map((category) => (
                        <button
                            type="button"
                            key={category}
                            className={category === activeCategory ? 'chip active' : 'chip'}
                            onClick={() => setActiveCategory(category)}
                        >
                            {category}
                        </button>
                    ))}
                </div>
                <div className="game-grid">
                    {displayGames.map((game, index) => (
                        <button
                            type="button"
                            key={game.id}
                            className="game-card"
                            style={{
                                animationDelay: `${120 + index * 70}ms`,
                                '--game-card-bg': `url(${game.icon || 'https://via.placeholder.com/300x200'})`,
                            }}
                            onClick={() => launchGame(game)}
                        >
                            <div className="game-thumb" aria-hidden="true">
                                <span>{game.label}</span>
                                <FaGamepad />
                            </div>
                            <div className="game-meta">
                                <h3>{game.name}</h3>
                                <p>{game.category ?? ""}</p>
                                <div className="game-row">
                                    <span>
                                        <FaUsers /> {game.players ?? ""}
                                    </span>
                                    <span>
                                        <FaFire /> {game.heat ?? 0}
                                    </span>
                                </div>
                            </div>
                        </button>
                    ))}
                </div>
            </section>

            <section className="card-shell">
                {renderSectionHeader('今日赢家榜', 'Slot 与休闲游戏实时赢币排行', '完整榜单')}
                <div className="leaderboard-list">
                    {leaderboard.map((item, idx) => (
                        <div className="leaderboard-item" key={item.name}>
                            <div className="rank-badge">#{idx + 1}</div>
                            <div>
                                <h3>{item.name}</h3>
                                <p>{item.streak}</p>
                            </div>
                            <strong>{item.score}</strong>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );

    const renderArena = () => (
        <div className="page-stack">
            <section className="card-shell headline-shell">
                <h2>Slot 赛事</h2>
                <p>规则透明、人数可见，所有赛事按统一结算标准发奖。</p>
            </section>

            <section className="card-shell arena-policy-shell">
                {renderSectionHeader('赛事通用规则', '报名前请先确认规则和结算时间', '完整规则')}
                <ul className="arena-list">
                    {arenaGlobalRules.map((rule) => (
                        <li key={rule}>{rule}</li>
                    ))}
                </ul>
            </section>

            {arenaCards.map((card, index) => (
                <section className="card-shell arena-card" key={card.id} style={{ animationDelay: `${index * 100}ms` }}>
                    <div className="arena-head">
                        <div>
                            <h3>{card.title}</h3>
                            <p>{card.mode}</p>
                        </div>
                        <span className="arena-prize">
                            <FaMedal /> {card.prize}
                        </span>
                    </div>
                    <div className="arena-meta-grid">
                        <article className="arena-metric">
                            <span>报名费</span>
                            <strong>{card.entryFee}</strong>
                        </article>
                        <article className="arena-metric">
                            <span>参赛要求</span>
                            <strong>{card.requirement}</strong>
                        </article>
                        <article className="arena-metric">
                            <span>结算时间</span>
                            <strong>{card.settlement}</strong>
                        </article>
                    </div>
                    <div className="arena-progress-label">
                        <span>{card.team}</span>
                        <span>{card.progress}%</span>
                    </div>
                    <div className="progress-track">
                        <div className="progress-value" style={{ width: `${card.progress}%` }} />
                    </div>
                    <div className="arena-detail-grid">
                        <article className="arena-block">
                            <h4>规则说明</h4>
                            <ul className="arena-list">
                                {card.rules.map((rule) => (
                                    <li key={rule}>{rule}</li>
                                ))}
                            </ul>
                        </article>
                        <article className="arena-block">
                            <h4>人员情况</h4>
                            <div className="roster-grid">
                                {card.personnel.map((info) => (
                                    <div className="roster-item" key={info.label}>
                                        <span>{info.label}</span>
                                        <strong>{info.value}</strong>
                                    </div>
                                ))}
                            </div>
                        </article>
                        <article className="arena-block">
                            <h4>奖励发放</h4>
                            <ul className="arena-list reward-list">
                                {card.rewards.map((reward) => (
                                    <li key={reward}>{reward}</li>
                                ))}
                            </ul>
                        </article>
                    </div>
                    <button type="button" className="btn-primary" onClick={() => setToast(`已报名 ${card.title}`)}>
                        <FaFlag />
                        报名参赛
                    </button>
                </section>
            ))}

            <section className="card-shell timeline-shell">
                <h3>今日赛事时段</h3>
                <div className="timeline-item">
                    <span>13:00</span>
                    <p>经典 Slot 冲榜场</p>
                </div>
                <div className="timeline-item">
                    <span>17:30</span>
                    <p>休闲积分赛</p>
                </div>
                <div className="timeline-item">
                    <span>21:00</span>
                    <p>Jackpot 决胜局</p>
                </div>
            </section>

            <section className="card-shell population-shell">
                <h3>全站参赛人员情况</h3>
                <div className="population-list">
                    {arenaPopulation.map((item) => (
                        <article className="population-item" key={item.label}>
                            <div className="population-head">
                                <span>{item.label}</span>
                                <strong>{item.value.toLocaleString()}</strong>
                            </div>
                            <div className="progress-track">
                                <div className="progress-value" style={{ width: `${item.ratio}%` }} />
                            </div>
                        </article>
                    ))}
                </div>
            </section>
        </div>
    );

    const renderEvents = () => (
        <div className="page-stack">
            <section className="card-shell split-shell">
                <div>
                    <h2>7 日签到</h2>
                    <p>连续签到可领取 Free Spin 和金币。</p>
                    <div className="checkin-grid">
                        {pickedDays.map((picked, index) => (
                            <button
                                type="button"
                                key={index}
                                className={picked ? 'checkin-day done' : 'checkin-day'}
                                onClick={() => claimDay(index)}
                            >
                                <span>D{index + 1}</span>
                                <strong>{picked ? '已领' : '领取'}</strong>
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            <section className="card-shell split-shell">
                <div>
                    <h2>幸运转盘</h2>
                    <p>每日 3 次免费机会，转中最高奖励 888 金币。</p>
                    <div className="wheel-wrap">
                        <div
                            className={isSpinning ? 'wheel spinning' : 'wheel'}
                            style={{ transform: `rotate(${spinAngle}deg)` }}
                            aria-hidden="true"
                        >
                            <span>188</span>
                            <span>388</span>
                            <span>588</span>
                            <span>888</span>
                        </div>
                        <button type="button" className="wheel-btn" onClick={spinLuckyWheel}>
                            <FaBolt /> 抽取
                        </button>
                    </div>
                </div>
            </section>

            <section className="card-shell">
                {renderSectionHeader('每日任务', '完成 Slot 与休闲任务，快速积累资源')}
                <div className="mission-list">
                    {missions.map((mission) => {
                        const percent = Math.round((mission.progress / mission.total) * 100);
                        return (
                            <article className="mission-item" key={mission.id}>
                                <div>
                                    <h3>{mission.title}</h3>
                                    <p>{renderRewardText(mission.coinReward, mission.tokenReward)}</p>
                                </div>
                                <div className="mission-track">
                                    <div className="progress-track">
                                        <div className="progress-value" style={{ width: `${percent}%` }} />
                                    </div>
                                    <span>
                                        {mission.progress}/{mission.total}
                                    </span>
                                </div>
                                <button type="button" className="btn-glass" onClick={() => claimMission(mission.id)}>
                                    领取
                                </button>
                            </article>
                        );
                    })}
                </div>
            </section>
        </div>
    );

    const renderStore = () => (
        <div className="page-stack">
            <section className="card-shell headline-shell">
                <h2>Slot 金币商城</h2>
                <p>专为 Slot 与休闲局准备的金币礼包，到账更快。</p>
            </section>

            <section className="card-shell">
                <div className="pack-grid">
                    {coinPacks.map((pack, index) => (
                        <article className="pack-card" key={pack.id} style={{ animationDelay: `${index * 80}ms` }}>
                            <span className="pack-tag">{pack.tag}</span>
                            <h3>{pack.coin}</h3>
                            <p>金币</p>
                            <p>送 {pack.tokenBonus} 活动币</p>
                            <strong>{pack.bonus}</strong>
                            <button type="button" className="btn-primary" onClick={() => buyPack(pack)}>
                                <FaWallet /> {pack.price}
                            </button>
                        </article>
                    ))}
                </div>
            </section>

            <section className="card-shell vip-shell">
                <div>
                    <h3>Slot 月度特权卡</h3>
                    <p>每天 1,000 金币 + 12 活动币 + 2 次免费旋转</p>
                </div>
                <button
                    type="button"
                    className="btn-primary"
                    onClick={() => {
                        setActivityCoins((prev) => prev + 120);
                        setToast('已开通月卡，赠送 120 活动币');
                    }}
                >
                    <FaCrown /> 立即开通
                </button>
            </section>

            <section className="card-shell exchange-shell">
                <h3>兑换码中心</h3>
                <div className="exchange-row">
                    <input placeholder="输入兑换码" />
                    <button type="button" className="btn-glass" onClick={() => setToast('兑换码已提交')}>
                        兑换
                    </button>
                </div>
            </section>
        </div>
    );

    const renderProfile = () => (
        <div className="page-stack">
            <section className="card-shell profile-hero">
                <div className="profile-top">
                    {avatar ? (
                        <img src={avatar} alt={nickname} className="avatar-ring" />
                    ) : (
                        <div className="avatar-ring">{nickname.charAt(0).toUpperCase()}</div>
                    )}
                    <div>
                        <h2>{nickname}</h2>
                        <p>ID: {playerStore.getUser().uid || '---'}</p>
                    </div>
                </div>
                <div className="stats-grid">
                    <article>
                        <span>总旋转</span>
                        <strong>12,480</strong>
                    </article>
                    <article>
                        <span>最高单次中奖</span>
                        <strong>88,800</strong>
                    </article>
                    <article>
                        <span>连中记录</span>
                        <strong>9</strong>
                    </article>
                    <article>
                        <span>本周收益</span>
                        <strong>+12,640</strong>
                    </article>
                </div>
            </section>

            <section className="card-shell">
                {renderSectionHeader('资产总览', '仅使用金币与活动币', '账单明细')}
                <div className="asset-grid">
                    <article>
                        <span>金币余额</span>
                        <strong>{coins.toLocaleString()}</strong>
                        <p>可用于 Slot 与休闲游戏内消耗</p>
                    </article>
                    <article>
                        <span>活动币余额</span>
                        <strong>{activityCoins.toLocaleString()}</strong>
                        <p>可在活动商店兑换入场券与外观</p>
                    </article>
                    <article>
                        <span>今日金币净收益</span>
                        <strong>+4,680</strong>
                        <p>来自 26 局 Slot 与 8 局休闲</p>
                    </article>
                    <article>
                        <span>今日活动币获得</span>
                        <strong>+18</strong>
                        <p>来源：任务、签到、转盘</p>
                    </article>
                </div>
            </section>

            <section className="card-shell">
                {renderSectionHeader('成就进度', '解锁 Slot 与休闲成就可获得稀有称号')}
                <div className="achievement-list">
                    <article>
                        <div>
                            <h3>百转达人</h3>
                            <p>累计完成 1,000 次旋转</p>
                        </div>
                        <span>82%</span>
                    </article>
                    <article>
                        <div>
                            <h3>Jackpot 猎手</h3>
                            <p>累计触发 20 次 Jackpot</p>
                        </div>
                        <span>48%</span>
                    </article>
                    <article>
                        <div>
                            <h3>休闲王者</h3>
                            <p>在休闲游戏中获胜 100 局</p>
                        </div>
                        <span>61%</span>
                    </article>
                </div>
            </section>

            <section className="card-shell">
                {renderSectionHeader('最近战绩', '展示最近 5 局金币与活动币变化', '更多记录')}
                <div className="record-list">
                    {profileRecords.map((record) => (
                        <article className="record-item" key={record.id}>
                            <div>
                                <h3>{record.game}</h3>
                                <p>
                                    {record.type} · {record.time}
                                </p>
                            </div>
                            <div className="record-change">
                                <strong className={record.coin >= 0 ? 'record-up' : 'record-down'}>
                                    {record.coin >= 0 ? '+' : ''}
                                    {record.coin.toLocaleString()} 金币
                                </strong>
                                <span>+{record.token} 活动币</span>
                            </div>
                        </article>
                    ))}
                </div>
            </section>

            <section className="card-shell">
                {renderSectionHeader('账号与安全', '设备、支付、登录保护状态', '安全中心')}
                <div className="account-list">
                    {profileSecurity.map((item) => (
                        <article className="account-item" key={item.label}>
                            <div>
                                <h3>{item.label}</h3>
                                <p>{item.value}</p>
                            </div>
                            <span>{item.status}</span>
                        </article>
                    ))}
                </div>
            </section>

            <section className="card-shell settings-list">
                <button type="button" onClick={() => setToast('音效设置已更新')}>
                    <FaBell /> 音效与震动
                    <FaChevronRight />
                </button>
                <button type="button" onClick={() => setToast('自动旋转设置已更新')}>
                    <FaBolt /> 自动旋转设置
                    <FaChevronRight />
                </button>
                <button type="button" onClick={() => setToast('奖励中心已打开')}>
                    <FaStar /> 奖励中心
                    <FaChevronRight />
                </button>
            </section>
        </div>
    );

    const renderCurrentTab = () => {
        if (activeTab === 'arena') {
            return renderArena();
        }
        if (activeTab === 'events') {
            return renderEvents();
        }
        if (activeTab === 'store') {
            return renderStore();
        }
        if (activeTab === 'profile') {
            return renderProfile();
        }
        return renderLobby();
    };

    return (
        <div className="app-root">
            <div className="bg-layer" aria-hidden="true" />

            <header className="top-bar">
                <div className="brand">
                    {avatar ? (
                        <img src={avatar} alt={nickname} className="avatar-img" />
                    ) : (
                        <div className="logo-dot" />
                    )}
                    <div>
                        <strong>{nickname}</strong>
                        <span>slot & casual lobby</span>
                    </div>
                </div>
                <div className="wallet-box">
                    <div>
                        <span>金币</span>
                        <strong>{coins.toLocaleString()}</strong>
                    </div>
                    <div>
                        <span>活动币</span>
                        <strong>{activityCoins.toLocaleString()}</strong>
                    </div>
                </div>
            </header>

            {/* 跑马灯公告 */}
            <div className="marquee-bar">
                <span className="marquee-label">公告</span>
                <div className="marquee-content">
                    <div className="marquee-text">
                        {apnsList.length > 0
                            ? apnsList.map((apns, index) => (
                                <span key={index} className="marquee-item">
                                    {apns.avatar ? (
                                        <img src={apns.avatar} alt={apns.nickname} className="marquee-avatar" />
                                    ) : (
                                        <span className="marquee-avatar-placeholder">
                                            {apns.nickname?.charAt(0).toUpperCase() || '?'}
                                        </span>
                                    )}
                                    恭喜玩家「{apns.nickname}」赢得 {apns.amount.toLocaleString()} 金币！
                                    {index < apnsList.length - 1 ? ' | ' : ''}
                                </span>
                            ))
                            : '🎰 每日签到奖励翻倍中，限时活动不容错过！ | 🏆 Slot 冲榜赛正在火热报名！ | 💰 新用户首充即享 40% 加赠！'
                        }
                    </div>
                </div>
            </div>

            <main className="content-shell">{renderCurrentTab()}</main>

            <nav className="bottom-nav" aria-label="主导航">
                {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                        <button
                            type="button"
                            key={tab.id}
                            className={activeTab === tab.id ? 'nav-item active' : 'nav-item'}
                            onClick={() => {
                                setActiveTab(tab.id)
                            }}
                        >
                            <Icon />
                            <span>{tab.label}</span>
                        </button>
                    );
                })}
            </nav>

            {selectedGame && (
                <div className="modal-mask" onClick={() => setSelectedGame(null)}>
                    <div className="modal-card" onClick={(event) => event.stopPropagation()}>
                        <div className="modal-header">
                            <h3>{selectedGame.name}</h3>
                            <button type="button" onClick={() => setSelectedGame(null)}>
                                关闭
                            </button>
                        </div>
                        <p>{selectedGame.category} | 实时在线 {selectedGame.players}</p>
                        <div className="modal-preview" aria-hidden="true">
                            <FaRocket />
                        </div>
                        <button
                            type="button"
                            className="btn-primary"
                            onClick={() => {
                                setToast(`正在进入 ${selectedGame.name}`);
                                console.log(selectedGame);
                                setSelectedGame(null);
                                // 在 iframe 中打开游戏
                                if (selectedGame.url) {
                                    setGameFrameUrl(selectedGame.url);
                                }
                            }}
                        >
                            <FaPlayCircle /> 立即开始
                        </button>
                    </div>
                </div>
            )}

            {/* 游戏 iframe 全屏窗口 */}
            {gameFrameUrl && (
                <div className="game-frame-overlay">
                    <button
                        type="button"
                        className="lobby-btn"
                        onClick={() => setGameFrameUrl(null)}
                    >
                        Lobby
                    </button>
                    <iframe
                        src={gameFrameUrl}
                        title="Game"
                        className="game-frame"
                        allow="fullscreen"
                    />
                </div>
            )}

            {toast && <div className="toast">{toast}</div>}

            {/* 连接状态遮罩 */}
            {connectionStatus !== 'connected' && (
                <div className="connection-overlay">
                    <div className="connection-box">
                        {connectionStatus === 'connecting' ? (
                            <>
                                <div className="spinner" />
                                <p className="connection-text">正在连接服务器...</p>
                            </>
                        ) : (
                            <>
                                <p className="connection-text error">{connectionError || '连接失败'}</p>
                                <button
                                    type="button"
                                    className="retry-btn"
                                    onClick={initializeConnection}
                                >
                                    重新连接
                                </button>
                            </>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default App;
