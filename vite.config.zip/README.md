# Game Lobby Client - 开发文档

## 项目简介

游戏大厅客户端是一个基于 React + Vite 构建的多语言游戏平台前端应用，提供大厅、游戏活动、任务系统、VIP 会员、个人中心等功能模块。

## 技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| React | ^19.2.0 | UI 框架 |
| Vite | ^7.2.4 | 构建工具 |
| React Icons | ^5.5.0 | 图标库 |
| ESLint | ^9.39.1 | 代码检查 |

## 环境要求

- **Node.js**: >= 20.19 或 >= 22.12
- **npm**: >= 9.0.0

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 开发模式

```bash
npm run dev
```

启动开发服务器，访问地址通常为 `http://localhost:5173`

### 3. 生产构建

```bash
npm run build
```

构建产物输出到 `dist/` 目录

### 4. 预览构建结果

```bash
npm run preview
```

## 项目结构

```
src/
├── assets/           # 静态资源
├── components/       # React 组件
│   ├── Achievements.jsx   # 成就系统组件
│   ├── Activities.jsx     # 活动页面组件
│   ├── BottomNav.jsx      # 底部导航组件
│   ├── GameGrid.jsx       # 游戏网格组件
│   ├── Header.jsx         # 顶部导航组件
│   ├── HUD.jsx            # 游戏信息显示组件
│   ├── VIPSystem.jsx      # VIP系统组件
│   └── *.css              # 组件样式文件
├── App.jsx          # 主应用组件
├── App.css          # 主样式文件
├── main.jsx         # 入口文件
├── index.css        # 全局样式
└── i18n.js          # 国际化配置
```

## 功能模块

### 1. 底部导航 (BottomNav)

底部导航栏，包含以下四个主要模块：
- **Lobby (大厅)**: 游戏列表展示
- **Activities (活动)**: 各类促销活动
- **Tasks (任务)**: 每日任务和阶梯任务
- **Profile (我的)**: 个人中心和设置

### 2. 活动系统 (Activities)

- 周末狂欢活动
- 每日签到 (7日签到奖励)
- 幸运转盘
- 限时礼包
- 充值返利活动

### 3. 任务系统 (Tasks)

- **每日任务**: 旋转50次、赢得1000金币、分享游戏、观看广告等
- **阶梯任务**: 青铜/白银/黄金三个等级

### 4. VIP 系统 (VIPSystem)

- VIP等级展示
- 升级进度
- VIP特权说明

### 5. 成就系统 (Achievements)

- 首战告捷
- 挥金如土
- 社交达人
- 持之以恒

## 国际化 (i18n)

项目支持 5 种语言：

| 语言代码 | 语言 | 说明 |
|----------|------|------|
| en | English | 英语 |
| zh | 中文 | 简体中文 |
| es | Español | 西班牙语 |
| pt | Português | 葡萄牙语 |
| fil | Filipino | 菲律宾语 |

国际化配置位于 `src/i18n.js`，可通过修改 `translations` 对象添加或修改翻译内容。

## 开发规范

### 代码风格

项目使用 ESLint 进行代码检查，配置位于 `eslint.config.js`。

### 组件开发

1. 组件文件使用 `.jsx` 扩展名
2. 样式文件使用同名的 `.css` 文件
3. 组件采用函数式组件 + Hooks 写法

### 提交规范

```
<type>: <description>

feat: 添加新功能
fix: 修复问题
docs: 文档更新
style: 代码格式调整
refactor: 重构
```

## 构建配置

Vite 配置位于 `vite.config.js`：

```javascript
export default defineConfig({
  plugins: [react()],
  base: './',  // 使用相对路径，适用于静态部署
})
```

## 常见问题

### Node.js 版本不兼容

```
Error: Vite requires Node.js version 20.19+ or 22.12+
```

**解决方案**: 升级 Node.js 到 20.19+ 或 22.12+

```bash
# 使用 nvm (推荐)
nvm install 22
nvm use 22

# 或使用 Homebrew
brew install node
```

### 权限问题

```
sh: /path/to/node_modules/.bin/vite: Permission denied
```

**解决方案**: 重新安装依赖或修复权限

```bash
rm -rf node_modules
npm install
```

## 许可证

本项目为私有项目，仅供内部使用。
