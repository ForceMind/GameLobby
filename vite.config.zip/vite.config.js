import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  base: './',
  assetsInclude: ['**/*.proto'],
  server: {
    proxy: {
      // 如果需要代理 API 请求可以在这里配置
    }
  }
})
